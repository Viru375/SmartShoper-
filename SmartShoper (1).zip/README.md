# SmartShoper

SmartShoper is a price comparison platform that fetches and displays product prices from different affiliate platforms.

## Features
- React frontend
- Node.js Express backend
- Placeholder for affiliate integration
- AI assistant and API ready structure
